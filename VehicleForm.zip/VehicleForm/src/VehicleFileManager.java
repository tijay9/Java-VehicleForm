import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class VehicleFileManager {
    private List<Vehicle> vehicles;
    private static final String FILE_PATH = "src/data/vehicles.csv";
    private VehicleForm vehicleForm;

    public VehicleFileManager() {
        vehicles = new ArrayList<>();
    }
    
    public VehicleFileManager(VehicleForm vehicleForm) {
        this();
        this.vehicleForm = vehicleForm;
    }

    public boolean isSameInstance(Vehicle vehicle) {
        return vehicles.contains(vehicle);
    }

    
    public void deleteTask(Vehicle vehicle, String task) {
        List<Vehicle> vehicles = loadVehicles();

        for (Vehicle v : vehicles) {
            if (v.getImmatriculation().equals(vehicle.getImmatriculation())) {
                v.removeTask(task);
                saveVehicles(vehicles); // Enregistrer les véhicules mis à jour dans le fichier CSV
                this.vehicles = vehicles; // Synchronise la liste en mémoire avec le fichier
                break;
            }
        }
    }



    public void saveVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        saveVehicles(vehicles);

        if (vehicleForm != null) {
        	vehicleForm.updateVehicleTable(vehicles);	
        }
    }
    
    public void deleteVehicle(String immatriculation) {
        List<Vehicle> updatedVehicles = new ArrayList<>();
        for (Vehicle vehicle : vehicles) {
            if (!vehicle.getImmatriculation().equals(immatriculation)) {
                updatedVehicles.add(vehicle);
            }
        }

        saveVehicles(updatedVehicles);

        vehicles = updatedVehicles;

    }



    public List<String> loadTasksForVehicle(Vehicle vehicle) {
        List<String> tasks = new ArrayList<>();
        // Load the vehicles from the CSV file
        List<Vehicle> loadedVehicles = loadVehicles();
        for (Vehicle v : loadedVehicles) {
            if (v.getImmatriculation().equals(vehicle.getImmatriculation())) {
                for (String task : v.getTasks()) {
                    tasks.add(task);
                }
                break;
            }
        }
        return tasks;
    }




    public void updateVehicle(Vehicle updatedVehicle) {
        // Load all vehicles from the file
        List<Vehicle> vehicles = loadVehicles();

        int vehicleIndex = -1;
        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.get(i).getImmatriculation().equals(updatedVehicle.getImmatriculation())) {
                vehicleIndex = i;
                break;
            }
        }
        if(vehicleIndex != -1) {
            // Update the existing vehicle
            vehicles.set(vehicleIndex, updatedVehicle);
        } else {
            // Add the new vehicle
            vehicles.add(updatedVehicle);
        }

        // Save the updated vehicles to the file
        saveVehicles(vehicles);
    }


    public void saveVehicles(List<Vehicle> vehicleList) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
            writer.println("ArrivalDate,Immatriculation,Marque,Modele,Couleur,Kilometrage,Tasks");
            for (Vehicle vehicle : vehicleList) {
                writer.print(vehicle.getArrivalDate() + ",");
                writer.print(vehicle.getImmatriculation() + ",");
                writer.print(vehicle.getMarque() + ",");
                writer.print(vehicle.getModele() + ",");
                writer.print(vehicle.getCouleur() + ",");
                writer.print(vehicle.getKilometrage() + ",");
                List<String> tasks = vehicle.getTasks();
                for (int i = 0; i < tasks.size(); i++) {
                    writer.print(tasks.get(i));
                    if (i != tasks.size() - 1) {
                        writer.print("|");
                    }
                }
                writer.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    
    }
    
    public void deleteTaskFromFile(Vehicle vehicle, String task) {
        try {
            File file = new File(FILE_PATH);
            File tempFile = new File("temp.csv");

            BufferedReader reader = new BufferedReader(new FileReader(file));
            PrintWriter writer = new PrintWriter(new FileWriter(tempFile));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[1].equals(vehicle.getImmatriculation())) {
                    if (data.length > 6 && !data[6].isEmpty()) {
                        String[] tasksData = data[6].split("\\|");
                        boolean taskFound = false;
                        for (String taskData : tasksData) {
                            if (taskData.equals(task)) {
                                taskFound = true;
                                break;
                            }
                        }
                        if (taskFound) {
                            // Remove the task from the tasksData array
                            List<String> updatedTasks = new ArrayList<>();
                            for (String taskData : tasksData) {
                                if (!taskData.equals(task)) {
                                    updatedTasks.add(taskData);
                                }
                            }
                            data[6] = String.join("|", updatedTasks);
                        }
                    }
                }
                writer.println(String.join(",", data));
            }

            reader.close();
            writer.close();

            // Replace the original file with the updated temporary file
            if (file.delete()) {
                if (!tempFile.renameTo(file)) {
                    System.out.println("Failed to rename temporary file.");
                }
            } else {
                System.out.println("Failed to delete the original file.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    


    private void updateVehiclesList(List<String> updatedLines) {
        vehicles.clear();

        for (String line : updatedLines) {
            String[] data = line.split(",");
            String arrivalDate = data[0];
            String immatriculation = data[1];
            String marque = data[2];
            String modele = data[3];
            String couleur = data[4];
            String kilometrage = data[5];

            Vehicle vehicle = new Vehicle(arrivalDate, immatriculation, marque, modele, couleur, kilometrage);

            if (data.length > 6 && !data[6].isEmpty()) {
                String[] tasksData = data[6].split("\\|");
                for (String taskData : tasksData) {
                    vehicle.addTask(taskData);
                }
            }

            vehicles.add(vehicle);
        }
    }

    private void saveLinesToFile(List<String> lines) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (String line : lines) {
                writer.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void saveVehicles() {
        saveVehicles(vehicles);
    }

    public boolean checkLicensePlateExists(String licensePlate) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getImmatriculation().equals(licensePlate)) {
                return true;
            }
        }
        return false;
    }

    public Vehicle getVehicleByLicensePlate(String licensePlate) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getImmatriculation().equals(licensePlate)) {
                return vehicle;
            }
        }
        return null;
    }


    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public Vehicle getVehicle(String immatriculation) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getImmatriculation().equals(immatriculation)) {
                return vehicle;
            }
        }
        return null;
    }

    public List<Vehicle> loadVehicles() {
        vehicles.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                String arrivalDate = data[0];
                String immatriculation = data[1];
                String marque = data[2];
                String modele = data[3];
                String couleur = data[4];
                String kilometrage = data[5];
                Vehicle vehicle = new Vehicle(arrivalDate, immatriculation, marque, modele, couleur, kilometrage);
                if (data.length > 6 && !data[6].isEmpty()) { // Check if the vehicle has tasks
                    String[] tasksData = data[6].split("\\|");
                    for (String taskData : tasksData) {
                        vehicle.addTask(taskData);
                    }
                }
                vehicles.add(vehicle);
            }
        } catch (FileNotFoundException e) {
            createFile(FILE_PATH);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return vehicles;
    }
    
    private void createFile(String filePath) {
        try {
            File file = new File(filePath);
            if (file.createNewFile()) {
                System.out.println("File created successfully: " + filePath);
            } else {
                System.out.println("File already exists: " + filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public void saveTask(Vehicle vehicle, String task, String frequency, String startDate, String endDate) {
        List<Vehicle> vehicles = loadVehicles();

        for (Vehicle v : vehicles) {
            if (v.getImmatriculation().equals(vehicle.getImmatriculation())) {
                // Update the task with the format: NomDeTache:Frequence:DateDebut:DateFin
                String updatedTask = task + ":" + frequency + ":" + startDate + ":" + endDate;

                // Add the new task to the vehicle's task list
                v.addTask(updatedTask);

                // Save the vehicles back to the file
                saveVehicles(vehicles);

                return;
            }
        }
    }


    public List<String> loadTasks(String immatriculation) {
        List<String> tasks = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Skip the header line
                }
                String[] data = line.split(",");
                if (immatriculation.equals(data[1])) {
                    if (data.length > 6 && !data[6].isEmpty()) {
                        String[] tasksData = data[6].split("\\|");
                        for (String taskData : tasksData) {
                            tasks.add(taskData);
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tasks;
    }
}
