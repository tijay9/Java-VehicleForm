	import java.util.ArrayList;
	import java.util.List;
	
	public class Vehicle {
	    private String arrivalDate;
	    private String immatriculation;
	    private String marque;
	    private String modele;
	    private String couleur;
	    private String kilometrage;
	    private List<String> tasks;

	    public Vehicle(String arrivalDate, String immatriculation, String marque, String modele, String couleur, String kilometrage) {
	        this.arrivalDate = arrivalDate;
	        this.immatriculation = immatriculation;
	        this.marque = marque;
	        this.modele = modele;
	        this.couleur = couleur;
	        this.kilometrage = kilometrage;
	        this.tasks = new ArrayList<>();
	        
	    }

	    public Vehicle(String immatriculation) {
	        this.immatriculation = immatriculation;
	        this.arrivalDate = "";
	        this.marque = "";
	        this.modele = "";
	        this.couleur = "";
	        this.kilometrage = "";
	        this.tasks = new ArrayList<>();
	    }
	
	    public String getArrivalDate() {
	        return arrivalDate;
	    }
	
	    public void setArrivalDate(String arrivalDate) {
	        this.arrivalDate = arrivalDate;
	    }
	
	    public String getImmatriculation() {
	        return immatriculation;
	    }
	
	    public void setImmatriculation(String immatriculation) {
	        this.immatriculation = immatriculation;
	    }
	
	    public String getMarque() {
	        return marque;
	    }
	
	    public void setMarque(String marque) {
	        this.marque = marque;
	    }
	
	    public String getModele() {
	        return modele;
	    }
	
	    public void setModele(String modele) {
	        this.modele = modele;
	    }
	
	    public String getCouleur() {
	        return couleur;
	    }
	
	    public void setCouleur(String couleur) {
	        this.couleur = couleur;
	    }
	
	    public String getKilometrage() {
	        return kilometrage;
	    }
	
	    public void setKilometrage(String kilometrage) {
	        this.kilometrage = kilometrage;
	    }
	
	    public List<String> getTasks() {
	        return tasks;
	    }
	
	    public void addTask(String task) {
	        tasks.add(task);
	    }
	
	    public void removeTask(String task) {
	        tasks.remove(task);
	    }
	    
	    public void setTasks(List<String> tasks) {
	        this.tasks = tasks;
	    }
	    
	    public void updateTask(String task, String updatedTask) {
	        int index = tasks.indexOf(task);
	        if (index != -1) {
	            tasks.set(index, updatedTask);
	        }
	    }

	}
