import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class EditForm extends JDialog {
    private Vehicle vehicle;
    private VehicleForm parentForm;
    private VehicleFileManager vehicleFileManager;

    private JTextField tfArrivalDate;
    private JTextField tfImmatriculation;
    private JTextField tfMarque;
    private JTextField tfModele;
    private JTextField tfCouleur;
    private JTextField tfKilometrage;

    public EditForm(Vehicle vehicle, VehicleForm parentForm, VehicleFileManager vehicleFileManager) {
    	try {
    	    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
    	        if ("Nimbus".equals(info.getName())) {
    	            UIManager.setLookAndFeel(info.getClassName());
    	            break;
    	        }
    	    }
    	} catch (Exception e) {
    	    // Si Nimbus n'est pas disponible, vous pouvez définir le Look & Feel par défaut.
    	}
        this.vehicle = vehicle;
        this.parentForm = parentForm;
        this.vehicleFileManager = vehicleFileManager;

        setTitle("Modifier le véhicule");
        setModal(true);
        setSize(300, 200);
        setLocationRelativeTo(parentForm.getFrame());

        setIconImage(Toolkit.getDefaultToolkit().getImage("src\\data\\img\\logo.png"));
        
        setupForm();
    }


    private void setupForm() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(6, 2));

        formPanel.add(new JLabel("Date d'arrivée du véhicule:"));
        tfArrivalDate = new JTextField(vehicle.getArrivalDate());
        formPanel.add(tfArrivalDate);

        formPanel.add(new JLabel("Immatriculation:"));
        tfImmatriculation = new JTextField(vehicle.getImmatriculation());
        formPanel.add(tfImmatriculation);

        formPanel.add(new JLabel("Marque:"));
        tfMarque = new JTextField(vehicle.getMarque());
        formPanel.add(tfMarque);

        formPanel.add(new JLabel("Modèle:"));
        tfModele = new JTextField(vehicle.getModele());
        formPanel.add(tfModele);

        formPanel.add(new JLabel("Couleur du véhicule:"));
        tfCouleur = new JTextField(vehicle.getCouleur());
        formPanel.add(tfCouleur);

        formPanel.add(new JLabel("Kilométrage:"));
        tfKilometrage = new JTextField(vehicle.getKilometrage());
        formPanel.add(tfKilometrage);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        JButton saveButton = new JButton("Enregistrer");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Récupérer les nouvelles valeurs des champs de texte
                String arrivalDate = tfArrivalDate.getText();
                String marque = tfMarque.getText();
                String modele = tfModele.getText();
                String couleur = tfCouleur.getText();
                String kilometrage = tfKilometrage.getText();

                // Mettre à jour le véhicule
                vehicle.setArrivalDate(arrivalDate);
                vehicle.setMarque(marque);
                vehicle.setModele(modele);
                vehicle.setCouleur(couleur);
                vehicle.setKilometrage(kilometrage);

                // Mettre à jour le véhicule dans le gestionnaire de fichiers
                vehicleFileManager.updateVehicle(vehicle);

                // Fermer la fenêtre de modification
                dispose();

                // Rafraîchir la liste des véhicules dans le formulaire principal
                parentForm.refreshVehicleTable();
            }

        });

        mainPanel.add(saveButton, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
    }
}
