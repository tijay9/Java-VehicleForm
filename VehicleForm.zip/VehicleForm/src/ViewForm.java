import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

    public class ViewForm extends JFrame {
        private Vehicle vehicle;
        private JButton generateHtmlButton;
        private VehicleFileManager vehicleFileManager;
        private JList<String> tasksList;
        private DefaultListModel<String> tasksListModel;
        private JTable tasksTable;
        private DefaultTableModel tasksTableModel;
        private JButton viewDatesButton;

        public ViewForm(Vehicle vehicle, VehicleFileManager vehicleFileManager) {
        	try {
        	    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        	        if ("Nimbus".equals(info.getName())) {
        	            UIManager.setLookAndFeel(info.getClassName());
        	            break;
        	        }
        	    }
        	} catch (Exception e) {
        	    // Si Nimbus n'est pas disponible, vous pouvez définir le Look & Feel par défaut.
        	}
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.vehicle = vehicle;
            this.vehicleFileManager = vehicleFileManager;
            setTitle("Détails du véhicule");
            getContentPane().setBackground(Color.DARK_GRAY);
            setSize(500, 375);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);

            tasksListModel = new DefaultListModel<>();
            tasksList = new JList<>(tasksListModel);

            setupForm();
            setupButtons();
            setupTasksTable();
            
            setIconImage(Toolkit.getDefaultToolkit().getImage("src\\data\\img\\logo.png"));
        }

        private void showError(String message) {
            JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
        }

        private void setupTasksTable() {
            tasksTableModel = new DefaultTableModel(new Object[]{"Nom de la tâche", "Fréquence", "Date de début", "Date de fin"}, 0);
            tasksTable = new JTable(tasksTableModel) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tasksTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Allow selecting only one row at a time
            tasksTable.setEnabled(true);
            JScrollPane tasksScrollPane = new JScrollPane(tasksTable);

            JPanel tasksPanel = new JPanel(new BorderLayout());
           
            tasksPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
            tasksPanel.add(tasksScrollPane, BorderLayout.CENTER);

            tasksTable.setBackground(Color.WHITE);  // Définir une couleur de fond
            tasksTable.setForeground(Color.BLACK);  // Changer la couleur du texte pour améliorer le contraste
            tasksTable.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
            
            add(tasksPanel, BorderLayout.CENTER);
        }


        private void setupForm() {
        	JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            mainPanel.setBackground(Color.LIGHT_GRAY);

            JPanel infoPanel = new JPanel(new GridLayout(6, 2));

            infoPanel.add(new JLabel("Date d'arrivée:"));
            infoPanel.add(new JLabel(vehicle.getArrivalDate()));

            infoPanel.add(new JLabel("Immatriculation:"));
            infoPanel.add(new JLabel(vehicle.getImmatriculation()));

            infoPanel.add(new JLabel("Marque:"));
            infoPanel.add(new JLabel(vehicle.getMarque()));

            infoPanel.add(new JLabel("Modèle:"));
            infoPanel.add(new JLabel(vehicle.getModele()));

            infoPanel.add(new JLabel("Couleur:"));
            infoPanel.add(new JLabel(vehicle.getCouleur()));

            infoPanel.add(new JLabel("Kilométrage:"));
            infoPanel.add(new JLabel(vehicle.getKilometrage()));

            mainPanel.add(infoPanel, BorderLayout.NORTH);

            add(mainPanel, BorderLayout.NORTH);
        }

        public void setTasks(List<String> tasks) {
            tasksTableModel.setRowCount(0); // Clear the table content

            for (String task : tasks) {
                String[] taskData = task.split(":");
                if (taskData.length == 4) {
                    String taskName = taskData[0].trim();
                    String frequency = taskData[1].trim();
                    String startDate = taskData[2].trim();
                    String endDate = taskData[3].trim();

                    tasksTableModel.addRow(new Object[]{taskName, frequency, startDate, endDate});
                }
            }
        }


        private void refreshTasksTable() {
            List<String> tasks = vehicleFileManager.loadTasksForVehicle(vehicle);
            setTasks(tasks);
        }

        public void setVisible(boolean visible) {
            super.setVisible(visible);

            if (visible) {
                refreshTasksTable();
            }
        }

        private void setupButtons() {
        	JPanel buttonPanel = new JPanel();
            buttonPanel.setBackground(Color.LIGHT_GRAY);  // Définir une couleur de fond

            generateHtmlButton = new JButton("Générer HTML");
            generateHtmlButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));  // Augmenter la taille de la police pour une meilleure lisibilité
            buttonPanel.add(generateHtmlButton);
            generateHtmlButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    generateHtmlPage();
                }
            });



            viewDatesButton = new JButton("Visualiser les dates");
            viewDatesButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            viewDatesButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    viewDueDates();
                }
            });
            buttonPanel.add(viewDatesButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        
        private void viewDueDates() {
            int selectedRow = tasksTable.getSelectedRow();
            if (selectedRow == -1) {
                showError("Veuillez sélectionner une tâche.");
                return;
            }

            String taskName = (String) tasksTableModel.getValueAt(selectedRow, 0);
            String frequency = (String) tasksTableModel.getValueAt(selectedRow, 1);
            String startDate = (String) tasksTableModel.getValueAt(selectedRow, 2);
            String endDate = (String) tasksTableModel.getValueAt(selectedRow, 3);

            String[] frequencyParts = frequency.split(" ");
            if (frequencyParts.length != 2) {
                showError("La fréquence de la tâche " + taskName + " n'est pas valide.");
                return;
            }

            String frequencyValue = frequencyParts[0];
            String unit = frequencyParts[1];

            List<String> dueDates;
            try {
                dueDates = DateHelper.generateDueDates(startDate, frequencyValue, unit, endDate);
            } catch (DateTimeParseException e) {
                showError("Les dates de la tâche " + taskName + " ne sont pas valides.");
                return;
            }

            // Créer une boîte de dialogue personnalisée pour afficher les dates dues
            JDialog dialog = new JDialog(this, "Dates dues pour la tâche " + taskName, true);
            dialog.setLayout(new BorderLayout());

            JPanel contentPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.WEST;
            gbc.insets = new Insets(5, 5, 5, 5);

            ImageIcon calendarIcon = new ImageIcon("calendar.png"); // Remplacez "calendar.png" par le chemin de votre icône de calendrier

            // Ajouter chaque date due dans un composant personnalisé
            for (String date : dueDates) {
                JLabel dateLabel = new JLabel(date);
                dateLabel.setIcon(calendarIcon);
                contentPanel.add(dateLabel, gbc);
                gbc.gridy++;
            }

            JScrollPane scrollPane = new JScrollPane(contentPanel);
            dialog.add(scrollPane, BorderLayout.CENTER);

            JButton closeButton = new JButton("Fermer");
            closeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    dialog.dispose();
                }
            });

            dialog.add(closeButton, BorderLayout.SOUTH);
            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }
        
        
        private void generateHtmlPage() {
            StringBuilder html = new StringBuilder();

            html.append("<!DOCTYPE html>\n");
            html.append("<html>\n");
            html.append("<head>\n");
            html.append("<title>Détails du véhicule : ").append(vehicle.getImmatriculation()).append("</title>\n");
            html.append("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css\">\n");
            html.append("<script src=\"https://cdn.jsdelivr.net/npm/flatpickr@4.6.13\"></script>\n");
            html.append("<style>\n");
            html.append("body {font-family: Arial, sans-serif; margin: 0; padding: 0; color: #333;}\n");
            html.append("h1 {background-color: #f8f8f8; padding: 20px; margin: 0; border-bottom: 1px solid #e7e7e7;}\n");
            html.append("table {border-collapse: collapse; width: 100%; margin-bottom: 20px;}\n");
            html.append("th, td {border: 1px solid #ddd; padding: 15px; text-align: left;}\n");
            html.append("th {background-color: #f2f2f2;}\n");
            html.append("tr:nth-child(even) {background-color: #f8f8f8;}\n");
            html.append(".has-action {\n");
            html.append("    position: relative;\n");
            html.append("}\n");
            html.append(".has-action:before {\n");
            html.append("    width: 10px;\n");
            html.append("    height: 10px;\n");
            html.append("    border-radius: 50%;\n");
            html.append("    background-color: red;\n");
            html.append("    content: \"\";\n");
            html.append("    position: absolute;\n");
            html.append("    bottom: 0;\n");
            html.append("    left: 50%;\n");
            html.append("    margin-left: -5px;\n");
            html.append("}\n");
            html.append("</style>\n");
            html.append("</head>\n");
            html.append("<body>\n");

            // Liste des informations du véhicule
            html.append("<h1>Informations du véhicule</h1>\n");
            html.append("<table>\n");
            html.append("<tr><th>Immatriculation</th><td>").append(vehicle.getImmatriculation()).append("</td></tr>\n");
            html.append("<tr><th>Marque</th><td>").append(vehicle.getMarque()).append("</td></tr>\n");
            html.append("<tr><th>Modèle</th><td>").append(vehicle.getModele()).append("</td></tr>\n");
            html.append("<tr><th>Couleur</th><td>").append(vehicle.getCouleur()).append("</td></tr>\n");
            html.append("<tr><th>Kilométrage</th><td>").append(vehicle.getKilometrage()).append("</td></tr>\n");
            html.append("</table>\n"); List<String> tasks = vehicleFileManager.loadTasksForVehicle(vehicle);
            html.append("<h1>Liste des tâches</h1>\n");
            html.append("<table>\n");
            html.append("<tr><th>Tâche</th><th>Début</th><th>Fin</th><th>Fréquence</th><th>Calendrier des tâches</th></tr>\n");
            int taskIndex = 1;
            for (String task : tasks) {
                String[] taskData = task.split(":");
                if (taskData.length == 4) {
                    String taskName = taskData[0].trim();
                    String taskNameId = taskName.replace(" ", "-").replace("'", "-");
                    String startDate = DateHelper.convertToFlatpickrFormat(taskData[2].trim());
                    String endDate = DateHelper.convertToFlatpickrFormat(taskData[3].trim());
                    String frequency = taskData[1].trim();

                    html.append("<tr>\n");
                    html.append("<td>").append(taskName).append("</td>\n");
                    html.append("<td>").append(startDate).append("</td>\n");
                    html.append("<td>").append(endDate).append("</td>\n");
                    html.append("<td>").append(frequency).append("</td>\n");
                    html.append("<td>\n");
                    html.append("<label for=\"").append(taskNameId).append("\">Calendrier des tâches</label>\n");
                    html.append("<input type=\"text\" id=\"").append(taskNameId).append("\" class=\"task-calendar flatpickr\">\n");
                    html.append("</td>\n");
                    html.append("</tr>\n");

                    String frequencyValue = frequency.split(" ")[0];
                    String unit = frequency.split(" ")[1];
                    List<String> dueDates = DateHelper.generateDueDates(taskData[2].trim(), frequencyValue, unit, taskData[3].trim());
                    dueDates = dueDates.stream().map(DateHelper::convertToFlatpickrFormat).collect(Collectors.toList());

                    html.append("<script>\n");
                    html.append("var coolDates").append(taskIndex).append(" = [\n");
                    for (String dueDate : dueDates) {
                        String[] dateParts = dueDate.split("-");
                        String year = dateParts[0];
                        String month = dateParts[1];
                        String day = dateParts[2];
                        html.append("    Date.parse(new Date(").append(year).append(", ").append(Integer.parseInt(month) - 1).append(", ").append(day).append(")),\n");
                    }
                    html.append("];\n");
                    html.append("flatpickr('#").append(taskNameId).append("', {\n");
                    html.append("    disable: [\n");
                    html.append("        function(date) {\n");
                    html.append("            return (date < coolDates").append(taskIndex).append("[0] || date > coolDates").append(taskIndex).append("[coolDates").append(taskIndex).append(".length - 1]);\n");
                    html.append("        }\n");
                    html.append("    ],\n");
                    html.append("    onDayCreate: function(dObj, dStr, fp, dayElem) {\n");
                    html.append("        if (coolDates").append(taskIndex).append(".indexOf(+dayElem.dateObj) !== -1) {\n");
                    html.append("            dayElem.classList.add('has-action');\n");
                    html.append("        }\n");
                    html.append("    }\n");
                    html.append("});\n");
                    html.append("</script>\n");

                    taskIndex++;
                }
            }
            html.append("</table>\n");

            html.append("<script src=\"https://cdn.jsdelivr.net/npm/flatpickr\"></script>\n");

            html.append("</body>\n");
            html.append("</html>\n");
        
    
            try {
                String filename = "VehicleDetails_" + vehicle.getImmatriculation() + ".html";
                File file = new File("src/data/html/" + filename);
                FileWriter fileWriter = new FileWriter(file);
                fileWriter.write(html.toString());
                fileWriter.close();
                JOptionPane.showMessageDialog(this, "La page HTML a été générée avec succès.", "Génération de la page HTML", JOptionPane.INFORMATION_MESSAGE);
            } 
            
            catch (IOException e) {
                showError("Erreur lors de la création du fichier HTML.");
            


    
    }
}
    }
    




