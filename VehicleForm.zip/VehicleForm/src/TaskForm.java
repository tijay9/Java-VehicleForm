import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

import com.toedter.calendar.JDateChooser;	

public class TaskForm extends JFrame {
    private JComboBox<String> taskComboBox;
    private JComboBox<String> frequencyComboBox;
    private JTextField frequencyTextField;
    private JButton addButton;
    private JList<String> taskList;
    private DefaultListModel<String> taskListModel;
    private JButton deleteButton;
    private List<String> tasksAdded;
    private Vehicle selectedVehicle;
    private VehicleFileManager vehicleFileManager;
    private JDateChooser startDateChooser;
    private JDateChooser endDateChooser;

    public TaskForm(String immatriculation) {
    	try {
    	    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
    	        if ("Nimbus".equals(info.getName())) {
    	            UIManager.setLookAndFeel(info.getClassName());
    	            break;
    	        }
    	    }
    	} catch (Exception e) {
    	    // Si Nimbus n'est pas disponible, vous pouvez définir le Look & Feel par défaut.
    	}
        vehicleFileManager = new VehicleFileManager(); // Initialize the VehicleFileManager
        vehicleFileManager.loadVehicles(); // Load the vehicles from the file

        selectedVehicle = vehicleFileManager.getVehicle(immatriculation);
        if (selectedVehicle == null) {
            // Show an error message if no vehicle with the given immatriculation is found
            showError("No vehicle found with the given immatriculation.");
            return;
        }

        tasksAdded = vehicleFileManager.loadTasksForVehicle(selectedVehicle);
        setupForm();
        setupButtons();
        setupTaskList();

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only the TaskForm, not the main VehicleForm
        setLocationRelativeTo(null); // Center the TaskForm on the screen
        setVisible(true);
        
        setIconImage(Toolkit.getDefaultToolkit().getImage("src\\data\\img\\logo.png"));
    }

    private void setupForm() {
    	JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel startDateLabel = new JLabel("Date de début:");
        startDateLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(startDateLabel);

        startDateChooser = new JDateChooser();
        formPanel.add(startDateChooser);

        JLabel endDateLabel = new JLabel("Date de fin:");
        formPanel.add(endDateLabel);

        endDateChooser = new JDateChooser();
        formPanel.add(endDateChooser);

        JLabel taskLabel = new JLabel("Choisir une tâche à ajouter:");
        formPanel.add(taskLabel);
        taskComboBox = new JComboBox<>();
        taskComboBox.setModel(new DefaultComboBoxModel<>(getAvailableTasks()));
        formPanel.add(taskComboBox);

        JLabel frequencyLabel = new JLabel("Fréquence:");
        frequencyLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(frequencyLabel);

        JPanel frequencyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        frequencyComboBox = new JComboBox<>();
        frequencyComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Jours", "Semaines", "Mois", "Années"}));
        frequencyPanel.add(frequencyComboBox);

        frequencyTextField = new JTextField(5);
        frequencyPanel.add(frequencyTextField);

        formPanel.add(frequencyPanel);

        add(formPanel, BorderLayout.NORTH);
    }

    private String[] getAvailableTasks() {
        String[] tasks = {
                "Plaquette de frein",
                "Liquide de freinage",
                "Vidange",
                "Révision",
                "Assurance",
                "Contrôle des pneus",
                "Niveau d'huile",
                "Liquide de refroidissement"
        };
        return tasks;
    }

    private void setupButtons() {
    	JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        addButton = new JButton("Ajouter");
        addButton.setBackground(new Color(25, 25, 112));
        addButton.setForeground(Color.WHITE);
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTask();
            }
        });

        deleteButton = new JButton("Supprimer");
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteSelectedTask();
            }
        });
        buttonPanel.add(deleteButton);

        buttonPanel.add(addButton);

        add(buttonPanel, BorderLayout.CENTER);
    }

    private void setupTaskList() {
    	taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setFont(new Font("Arial", Font.PLAIN, 14));

        // Add tasks from the selected vehicle to the list model
        for (String task : tasksAdded) {
            taskListModel.addElement(task);
        }

        taskList = new JList<>(taskListModel);
        // taskList.setEnabled(false); // Comment or remove this line to allow item selection.

        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Tâches ajoutées"));
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void deleteSelectedTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Êtes-vous sûr de vouloir supprimer cette tâche ?", "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String selectedTask = taskListModel.getElementAt(selectedIndex);
                selectedVehicle.removeTask(selectedTask); // Remove the task from the vehicle object

                // Call the deleteTaskFromFile method to update the file
                vehicleFileManager.deleteTaskFromFile(selectedVehicle, selectedTask);

                // Update the task list
                tasksAdded = vehicleFileManager.loadTasksForVehicle(selectedVehicle);
                taskListModel.clear();
                for (String task : tasksAdded) {
                    taskListModel.addElement(task);
                }

                showMessage("La tâche a été supprimée avec succès.");
            }
        } else {
            showError("Veuillez sélectionner une tâche à supprimer.");
        }
    }


    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Confirmation", JOptionPane.INFORMATION_MESSAGE);
    }

    private void addTask() {
        // Get the selected task, frequency, start date, and end date
        String selectedTask = (String) taskComboBox.getSelectedItem();
        String frequencyValue = frequencyComboBox.getSelectedItem().toString();
        String frequencyText = frequencyTextField.getText() + " " + frequencyValue;
        Date startDate = startDateChooser.getDate();
        Date endDate = endDateChooser.getDate();

        // Validate the fields
        if (selectedTask.isEmpty() || frequencyText.isEmpty() || startDate == null || endDate == null) {
            showError("Veuillez remplir tous les champs.");
            return;
        }

        // Validate the task name
        if (taskListModel.contains(selectedTask)) {
            showError("La tâche sélectionnée existe déjà.");
            return;
        }

        // Validate the frequency value
        String frequencyValueText = frequencyTextField.getText();
        if (!isPositiveInteger(frequencyValueText)) {
            showError("La fréquence doit être un entier positif.");
            return;
        }

        int frequencyValueInt = Integer.parseInt(frequencyValueText);
        int daysBetween = (int) ((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

        // Validate the frequency interval
        if (frequencyValueInt > daysBetween) {
            showError("La fréquence ne peut pas être supérieure à l'intervalle entre les dates de début et de fin.");
            return;
        }

        // Format the dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedStartDate = dateFormat.format(startDate);
        String formattedEndDate = dateFormat.format(endDate);

        // Call the updated saveTask method
        vehicleFileManager.saveTask(selectedVehicle, selectedTask, frequencyText, formattedStartDate, formattedEndDate);

        // Reload tasks
        tasksAdded = vehicleFileManager.loadTasksForVehicle(selectedVehicle);
        taskListModel.clear();
        for (String task : tasksAdded) {
            taskListModel.addElement(task);
        }

        // Clear form fields
        taskComboBox.setSelectedIndex(0);
        frequencyTextField.setText("");
        startDateChooser.setDate(null);
        endDateChooser.setDate(null);

        showMessage("La tâche a été ajoutée avec succès.");
    }



    private boolean isPositiveInteger(String value) {
        try {
            int intValue = Integer.parseInt(value);
            return intValue > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Erreur", JOptionPane.ERROR_MESSAGE);
    }





}
