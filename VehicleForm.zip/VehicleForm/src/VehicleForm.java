import javax.mail.internet.NewsAddress;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.DrbgParameters.NextBytes;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class VehicleForm {
    private JFrame frame;
    private JPanel mainPanel;
    private JPanel vehicleForm;
    private DefaultTableModel vehicleTableModel;
    private JTable vehicleTable;
    private JFormattedTextField arrivalDateField;
    private JTextField tfImmatriculation;
    private JTextField tfMarque;
    private JTextField tfModele;
    private JTextField tfCouleur;
    private JTextField tfKilometrage;
    private JButton addButton;
    private JButton editButton;
    private JButton viewButton;
    private JButton manageTasksButton;
    private VehicleFileManager vehicleFileManager;
    private VehicleForm parentForm;
    private JTextField searchField;

    public VehicleForm() {
    	try {
    	    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
    	        if ("Nimbus".equals(info.getName())) {
    	            UIManager.setLookAndFeel(info.getClassName());
    	            break;
    	        }
    	    }
    	} catch (Exception e) {
    	    // Si Nimbus n'est pas disponible, vous pouvez définir le Look & Feel par défaut.
    	}
        frame = new JFrame();
        frame.getContentPane().setBackground(Color.DARK_GRAY);
        frame.setSize(800, 600);
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.GRAY);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        vehicleForm = new JPanel(new GridLayout(0, 2));
        vehicleTableModel = new DefaultTableModel();
        vehicleFileManager = new VehicleFileManager();

        setupForm();
        setupTable();
        setupButtons();

        mainPanel.add(vehicleForm, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(vehicleTable), BorderLayout.CENTER);

        frame.add(mainPanel);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage("src\\data\\img\\logo.png"));
        frame.setVisible(true);

        vehicleFileManager.loadVehicles();
        loadVehiclesFromManager();
    }

    private void setupForm() {
    	vehicleForm.setBorder(new EmptyBorder(10, 10, 10, 10));
        vehicleForm.setBackground(Color.GRAY);
        

        vehicleForm.add(new JLabel("Date d'arrivée du véhicule:"));
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        arrivalDateField = new JFormattedTextField(format);
        arrivalDateField.setValue(new Date());
        vehicleForm.add(arrivalDateField);

        vehicleForm.add(new JLabel("Immatriculation:"));
        tfImmatriculation = new JTextField();
        vehicleForm.add(tfImmatriculation);

        vehicleForm.add(new JLabel("Marque:"));
        tfMarque = new JTextField();
        vehicleForm.add(tfMarque);

        vehicleForm.add(new JLabel("Modèle:"));
        tfModele = new JTextField();
        vehicleForm.add(tfModele);

        vehicleForm.add(new JLabel("Couleur du véhicule:"));
        tfCouleur = new JTextField();
        vehicleForm.add(tfCouleur);

        vehicleForm.add(new JLabel("Kilométrage:"));
        tfKilometrage = new JTextField();
        vehicleForm.add(tfKilometrage);

        JPanel searchPanel = new JPanel(new BorderLayout());
        JLabel searchLabel = new JLabel("Rechercher:");
        searchField = new JTextField();
        searchPanel.setBackground(Color.GRAY);
        searchLabel.setForeground(Color.WHITE);  
        searchField.setBackground(Color.WHITE);
        searchField.setForeground(Color.BLACK);
        searchPanel.add(searchLabel, BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        vehicleForm.add(searchPanel);
    }

    private void setupTable() {
        vehicleTableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        vehicleTableModel.addColumn("Date d'arrivée");
        vehicleTableModel.addColumn("Immatriculation");
        vehicleTableModel.addColumn("Marque");
        vehicleTableModel.addColumn("Modèle");
        vehicleTableModel.addColumn("Couleur");
        vehicleTableModel.addColumn("Kilométrage");

        vehicleTable = new JTable(vehicleTableModel);
        vehicleTable.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        vehicleTable.getTableHeader().setReorderingAllowed(false);

        // Set column widths
        vehicleTable.getColumnModel().getColumn(0).setMinWidth(0); // Date d'arrivée
        vehicleTable.getColumnModel().getColumn(0).setMaxWidth(0);
        vehicleTable.getColumnModel().getColumn(4).setMinWidth(0); // Couleur
        vehicleTable.getColumnModel().getColumn(4).setMaxWidth(0);
        vehicleTable.getColumnModel().getColumn(5).setMinWidth(0); // Kilométrage
        vehicleTable.getColumnModel().getColumn(5).setMaxWidth(0);

        // Activer la sélection des cellules
        vehicleTable.setCellSelectionEnabled(true);
        
        
        vehicleTable.setBackground(Color.WHITE);  // Définir une couleur de fond
        vehicleTable.setForeground(Color.BLACK);  // Changer la couleur du texte pour améliorer le contraste
        vehicleTable.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));

        // Ajouter un écouteur d'événements de sélection à la table
        vehicleTable.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = vehicleTable.getSelectedRow();
            if (selectedRow != -1) {
                // Un élément a été sélectionné, activer le bouton de visualisation
                viewButton.setEnabled(true);
            } else {
                // Aucun élément sélectionné, désactiver le bouton de visualisation
                viewButton.setEnabled(false);
            }
        });
    }




    private void setupButtons() {
    	 
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        buttonPanel.setBackground(Color.LIGHT_GRAY);

        addButton = new JButton("Ajouter");
        addButton.addActionListener(e -> addVehicleToTable());
        buttonPanel.add(addButton);
        
       

        JButton deleteButton = new JButton("Supprimer");
        deleteButton.addActionListener(e -> deleteSelectedVehicle());
        buttonPanel.add(deleteButton);
        

        editButton = new JButton("Modifier");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = vehicleTable.getSelectedRow();
                if (selectedRow != -1) {
                    Vehicle vehicle = getSelectedVehicle();
                    EditForm editForm = new EditForm(vehicle, VehicleForm.this, vehicleFileManager);
                    editForm.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un véhicule à modifier.", "Aucun véhicule sélectionné", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        buttonPanel.add(editButton);

        viewButton = new JButton("Visualiser");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewSelectedVehicle();
            }
        });
        buttonPanel.add(viewButton);

        manageTasksButton = new JButton("Gérer les tâches");
        manageTasksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manageTasks();
            }
        });
        buttonPanel.add(manageTasksButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Ajout de l'écouteur pour la barre de recherche
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filterVehicleList(searchField.getText());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filterVehicleList(searchField.getText());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filterVehicleList(searchField.getText());
            }
        });
    }
    
    private void filterVehicleList(String searchText) {
        DefaultTableModel filteredModel = new DefaultTableModel();
        filteredModel.setColumnIdentifiers(new String[]{"Immatriculation", "Marque", "Modèle"});

        for (int i = 0; i < vehicleTableModel.getRowCount(); i++) {
            boolean matchFound = false;
            for (int j = 1; j < vehicleTableModel.getColumnCount(); j++) {
                String cellValue = vehicleTableModel.getValueAt(i, j).toString().toLowerCase();
                if (cellValue.contains(searchText.toLowerCase())) {
                    matchFound = true;
                    break;
                }
            }

            if (matchFound) {
                Object[] rowData = new Object[3];
                rowData[0] = vehicleTableModel.getValueAt(i, 1); // Immatriculation
                rowData[1] = vehicleTableModel.getValueAt(i, 2); // Marque
                rowData[2] = vehicleTableModel.getValueAt(i, 3); // Modèle
                filteredModel.addRow(rowData);
            }
        }

        vehicleTable.setModel(filteredModel);
    }



    private void viewSelectedVehicle() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            Vehicle vehicle = getSelectedVehicle();
            ViewForm viewForm = new ViewForm(vehicle, vehicleFileManager);
            
            // Load tasks for the selected vehicle
            List<String> tasks = vehicleFileManager.loadTasksForVehicle(vehicle);
            viewForm.setTasks(tasks);
            
            viewForm.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un véhicule à visualiser.", "Aucun véhicule sélectionné", JOptionPane.WARNING_MESSAGE);
        }
    }


    

    private void addVehicleToTable() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        String arrivalDate = format.format(arrivalDateField.getValue());
        String immatriculation = tfImmatriculation.getText();
        String marque = tfMarque.getText();
        String modele = tfModele.getText();
        String couleur = tfCouleur.getText();
        String kilometrage = tfKilometrage.getText();

        // Check i	f the license plate is already assigned to another vehicle
        boolean licensePlateExists = vehicleFileManager.checkLicensePlateExists(immatriculation);
        if (licensePlateExists) {
            JOptionPane.showMessageDialog(frame, "La plaque d'immatriculation est déjà attribuée à un autre véhicule.", "Erreur de saisie", JOptionPane.ERROR_MESSAGE);
        } else if (!immatriculation.isEmpty() && !marque.isEmpty() && !modele.isEmpty() && !couleur.isEmpty() && !kilometrage.isEmpty()) {
            Object[] rowData = {arrivalDate, immatriculation, marque, modele, couleur, kilometrage};
            vehicleTableModel.addRow(rowData);

            Vehicle vehicle = new Vehicle(arrivalDate, immatriculation, marque, modele, couleur, kilometrage);
            vehicleFileManager.saveVehicle(vehicle);
            vehicleFileManager.saveVehicles();

            clearFormFields();
        } else {
            JOptionPane.showMessageDialog(frame, "Veuillez remplir tous les champs du formulaire.", "Erreur de saisie", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void manageTasks() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            Vehicle vehicle = getSelectedVehicle();

            TaskForm taskForm = new TaskForm(vehicle.getImmatriculation()); 
            taskForm.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un véhicule pour gérer les tâches.", "Aucun véhicule sélectionné", JOptionPane.WARNING_MESSAGE);
        }
    }

    
    private Vehicle getSelectedVehicle() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            String arrivalDate = (String) vehicleTableModel.getValueAt(selectedRow, 0);
            String immatriculation = (String) vehicleTableModel.getValueAt(selectedRow, 1);
            String marque = (String) vehicleTableModel.getValueAt(selectedRow, 2);
            String modele = (String) vehicleTableModel.getValueAt(selectedRow, 3);
            String couleur = (String) vehicleTableModel.getValueAt(selectedRow, 4);
            String kilometrage = (String) vehicleTableModel.getValueAt(selectedRow, 5);

            return new Vehicle(arrivalDate, immatriculation, marque, modele, couleur, kilometrage);
        }
        return null;
    }

    public JFrame getFrame() {
        return frame;
    }
    
    
    public void refreshVehicleTable() {
        // Clear the current table data
        vehicleTableModel.setRowCount(0);

        // Load the vehicles from the file manager
        vehicleFileManager.loadVehicles();
        List<Vehicle> vehicles = vehicleFileManager.getVehicles();

        // Add the vehicles to the table model
        for (Vehicle vehicle : vehicles) {
            Object[] rowData = {vehicle.getArrivalDate(), vehicle.getImmatriculation(), vehicle.getMarque(),
                    vehicle.getModele(), vehicle.getCouleur(), vehicle.getKilometrage()};
            vehicleTableModel.addRow(rowData);
        }
    }


    private void deleteSelectedVehicle() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            int confirmation = JOptionPane.showConfirmDialog(frame, "Êtes-vous sûr de vouloir supprimer ce véhicule ?", "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
            if (confirmation == JOptionPane.YES_OPTION) {
                String immatriculation = (String) vehicleTableModel.getValueAt(selectedRow, 1);
                vehicleTableModel	.removeRow(selectedRow);
                vehicleFileManager.deleteVehicle(immatriculation);
                vehicleFileManager.saveVehicles();
            }
        }
    }

    private void clearFormFields() {
        arrivalDateField.setValue(new Date());
        tfImmatriculation.setText("");
        tfMarque.setText("");
        tfModele.setText("");
        tfCouleur.setText("");
        tfKilometrage.setText("");
    }

    private void loadVehiclesFromManager() {
        List<Vehicle> vehicles = vehicleFileManager.getVehicles();
        for (Vehicle vehicle : vehicles) {
            Object[] rowData = {vehicle.getArrivalDate(), vehicle.getImmatriculation(), vehicle.getMarque(),
                    vehicle.getModele(), vehicle.getCouleur(), vehicle.getKilometrage()};
            vehicleTableModel.addRow(rowData);
        }
    }

    public void updateVehicle(Vehicle vehicle) {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            vehicleTableModel.setValueAt(vehicle.getArrivalDate(), selectedRow, 0);
            vehicleTableModel.setValueAt(vehicle.getImmatriculation(), selectedRow, 1);
            vehicleTableModel.setValueAt(vehicle.getMarque(), selectedRow, 2);
            vehicleTableModel.setValueAt(vehicle.getModele(), selectedRow, 3);
            vehicleTableModel.setValueAt(vehicle.getCouleur(), selectedRow, 4);
            vehicleTableModel.setValueAt(vehicle.getKilometrage(), selectedRow, 5);
            vehicleFileManager.saveVehicles();
        }
    }
    
    public void updateVehicleTable(List<Vehicle> vehicles) {
        // Clear the current table data
        vehicleTableModel.setRowCount(0);

        // Add the vehicles to the table model
        for (Vehicle vehicle : vehicles) {
            Object[] rowData = {vehicle.getArrivalDate(), vehicle.getImmatriculation(), vehicle.getMarque(),
                    vehicle.getModele(), vehicle.getCouleur(), vehicle.getKilometrage()};
            vehicleTableModel.addRow(rowData);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VehicleForm::new);
    }
}
