import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class DateHelper {

	public static List<String> generateDueDates(String startDate, String frequencyValue, String unit, String endDate) {
        List<String> allDueDates = new ArrayList<>();

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        LocalDate start = LocalDate.parse(startDate, dateFormatter);
        LocalDate end = null;
        if (endDate != null && !endDate.isEmpty()) {
            end = LocalDate.parse(endDate, dateFormatter);
        }

        LocalDate nextDueDate = start;
        int frequency = Integer.parseInt(frequencyValue);

        while (end == null || nextDueDate.isBefore(end) || nextDueDate.isEqual(end)) {
            allDueDates.add(nextDueDate.format(dateFormatter));
            switch (unit) {
                case "Jours":
                    nextDueDate = nextDueDate.plusDays(frequency);
                    break;
                case "Semaines":
                    nextDueDate = nextDueDate.plusWeeks(frequency);
                    break;
                case "Mois":
                    nextDueDate = nextDueDate.plusMonths(frequency);
                    break;
                case "Années":
                    nextDueDate = nextDueDate.plusYears(frequency);
                    break;
            }
        }

        return allDueDates;
    }
	
	
	public static String convertToFlatpickrFormat(String date) {
        DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate parsedDate = LocalDate.parse(date, inputFormat);
        return parsedDate.format(outputFormat);
    }
	
	
	public static String convertToFullCalendarFormat(String date) {
	    DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	    DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    LocalDate parsedDate = LocalDate.parse(date, inputFormat);
	    return parsedDate.format(outputFormat);
	}
	
	


}
